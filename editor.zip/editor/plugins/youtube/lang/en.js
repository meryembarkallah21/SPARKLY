CKEDITOR.plugins.setLang('youtube', 'en',
{
  youtube : 
  {
    title : "Embed Youtube Video",
    button : "Add Youtube Video",
    pasteMsg : "Please copy and paste the Youtube URL here"
  }
});
