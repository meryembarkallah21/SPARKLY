/*!
 * remark v1.0.1 (http://getbootstrapadmin.com/remark)
 * Copyright 2015 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */
$.components.register("webuiPopover", {
  mode: "default",
  defaults: {
    trigger: "click",
    width: 320,
    multi: true,
    cloaseable: false,
    style: "",
    delay: 300,
    padding: true
  }
});
